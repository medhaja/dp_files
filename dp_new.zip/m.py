"""Training a CNN on MNIST with Keras and the DP SGD optimizer."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import cv2
import tensorflow as tf
import pickle
import numpy as np
import keras
from keras import backend as K
from keras.models import Sequential
from keras.layers import Activation
from keras.layers.core import Dense, Flatten,Dropout
from keras.optimizers import Adam
from keras.metrics import categorical_crossentropy
from keras.preprocessing.image import ImageDataGenerator
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import *
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
import itertools
import random



from rdp_accountant import compute_rdp
from rdp_accountant import get_privacy_spent
from gaussian_query import GaussianAverageQuery
from dp_optimizer import DPGradientDescentOptimizer

# Compatibility with tf 1 and 2 APIs
try:
  GradientDescentOptimizer = tf.train.GradientDescentOptimizer
except:  # pylint: disable=bare-except
  GradientDescentOptimizer = tf.optimizers.SGD  # pylint: disable=invalid-name

tf.flags.DEFINE_boolean('dpsgd', True, 'If True, train with DP-SGD. If False, '
                        'train with vanilla SGD.')
tf.flags.DEFINE_float('learning_rate', 0.15, 'Learning rate for training')
tf.flags.DEFINE_float('noise_multiplier', 1.1,
                      'Ratio of the standard deviation to the clipping norm')
tf.flags.DEFINE_float('l2_norm_clip', 1.0, 'Clipping norm')
tf.flags.DEFINE_integer('batch_size', 32, 'Batch size')
tf.flags.DEFINE_integer('epochs', 6, 'Number of epochs')
tf.flags.DEFINE_integer('microbatches', 32, 'Number of microbatches '
                        '(must evenly divide batch_size)')
tf.flags.DEFINE_string('model_dir', None, 'Model directory')

FLAGS = tf.flags.FLAGS

def compute_epsilon(steps):
  """Computes epsilon value for given hyperparameters."""
  if FLAGS.noise_multiplier == 0.0:
    return float('inf')
  orders = [1 + x / 10. for x in range(1, 100)] + list(range(12, 64))
  sampling_probability = FLAGS.batch_size / 60000
  rdp = compute_rdp(q=sampling_probability,
                    noise_multiplier=FLAGS.noise_multiplier,
                    steps=steps,
                    orders=orders)
  # Delta is set to 1e-5 because MNIST has 60000 training points.
  return get_privacy_spent(orders, rdp, target_delta=1e-5)[0]


def load_mnist():
    train, test = tf.keras.datasets.mnist.load_data()
    train_data, train_labels = train
    test_data, test_labels = test
    train_data = np.array(train_data, dtype=np.float32) / 255
    test_data = np.array(test_data, dtype=np.float32) / 255
    train_data = train_data.reshape(train_data.shape[0], 28, 28, 1)
    test_data = test_data.reshape(test_data.shape[0], 28, 28, 1)
    train_labels = np.array(train_labels, dtype=np.int32)
    test_labels = np.array(test_labels, dtype=np.int32)
    train_labels = tf.keras.utils.to_categorical(train_labels, num_classes=10)
    test_labels = tf.keras.utils.to_categorical(test_labels, num_classes=10)
    aa=[np.where(r==1)[0][0] for r in train_labels]
    aa= np.array(aa)
    aaa=[np.where(r==1)[0][0] for r in test_labels]
    aaa = np.array(aaa)
    train = []
    for i in train_data[:500]:
        rgb = cv2.cvtColor(i,cv2.COLOR_GRAY2RGB)
        img = cv2.resize(rgb,(224,224))
        train.append(img)
    test = []
    for i in test_data[:100]:
        rgb = cv2.cvtColor(i,cv2.COLOR_GRAY2RGB)
        img = cv2.resize(rgb,(224,224))
        test.append(img)
    train_out = np.array(train[:500])
    test_out = np.array(test[:100])
    print(train_data.shape)
    print(test_data.shape)
    return train_data, aa, test_data , aaa

#a,b,c,d = load_mnist()
#print((a.shape))
#print((b.shape))
#print((c.shape))
#print((d.shape))

def load_data1():
  x = open('x.pickle','rb')
  data_x = pickle.load(x)
  
  y = open('y.pickle','rb')
  data_y = pickle.load(y)
  
  train_data = data_x[:400]
  test_data =data_x[400:511]
  train_labels = data_y[:400]
  test_labels = data_y[400:511]
  
  train_data = np.array(train_data, dtype=np.float32) / 255
  test_data = np.array(test_data, dtype=np.float32) / 255
  train_labels = np.array(train_labels, dtype=np.int32)
  test_labels = np.array(test_labels, dtype=np.int32)
  
  #train_data = train_data.reshape(train_data.shape[0], 224, 224)
  #test_data = test_data.reshape(test_data.shape[0], 224, 224)
  print(train_data.shape)
  print(test_data.shape)
  return train_data, train_labels, test_data, test_labels
#a,b,c,d = load_data1()

#a.shape

def main(unused_argv):
  tf.logging.set_verbosity(tf.logging.INFO)
  if FLAGS.dpsgd and FLAGS.batch_size % FLAGS.microbatches != 0:
    raise ValueError('Number of microbatches should divide evenly batch_size')

  # Load training and test data.
  train_data, train_labels, test_data, test_labels = load_data1()
  '''

  x_train_lt5 = train_data[train_labels < 5]
  y_train_lt5 = train_labels[train_labels < 5]
  x_test_lt5 = train_data[train_labels < 5]
  y_test_lt5 = train_labels[train_labels < 5]
  x_train_gte5 = train_data[train_labels >= 5]
  y_train_gte5 = train_labels[train_labels >= 5] - 5
  x_test_gte5 = train_data[train_labels >= 5]
  y_test_gte5 = train_labels[train_labels >= 5] - 5



  #print(np.shape(test_labels))
  # Define a sequential Keras model
  model = tf.keras.Sequential([
      tf.keras.layers.Conv2D(16, 8,
                             strides=2,
                             padding='same',
                             activation='relu',
                             input_shape=(28, 28, 1)),
      tf.keras.layers.MaxPool2D(2, 1),
      tf.keras.layers.Conv2D(32, 4,
                             strides=2,
                             padding='valid',
                             activation='relu'),
      tf.keras.layers.MaxPool2D(2, 1),
      tf.keras.layers.Flatten(),
      tf.keras.layers.Dense(32, activation='relu'),
      tf.keras.layers.Dense(10)
  ])

  '''
  v_model=keras.applications.vgg16.VGG16()
  model=Sequential()
  #model.add(Conv2D(32, 3, 3, input_shape=(224,224,3)))
  #model.add(MaxPooling2D(pool_size=(2, 2)))
  for layer in v_model.layers[:-1]:
    model.add(layer)
  for layer in model.layers:
    layer.trainable=False
  
  from keras.layers import Dense, Dropout, Activation
  model.add(Dense(128,activation="softmax"))
  model.add(Dropout(0.5))
  model.add(Dense(64,activation="softmax"))
  #model.add(Dropout(0.5))
  model.add(Dense(2,activation="softmax"))
  if FLAGS.dpsgd:
    dp_average_query = GaussianAverageQuery(
        FLAGS.l2_norm_clip,
        FLAGS.l2_norm_clip * FLAGS.noise_multiplier,
        FLAGS.microbatches)
    optimizer = DPGradientDescentOptimizer(
        dp_average_query,
        FLAGS.microbatches,
        learning_rate=FLAGS.learning_rate,
        unroll_microbatches=True)
    # Compute vector of per-example loss rather than its mean over a minibatch.
    loss = tf.keras.losses.CategoricalCrossentropy(
        from_logits=True, reduction=tf.losses.Reduction.NONE)
  else:
    optimizer = GradientDescentOptimizer(learning_rate=FLAGS.learning_rate)
    loss = tf.keras.losses.CategoricalCrossentropy(from_logits=True)

  # Compile model with Keras
  model.compile(optimizer=optimizer, loss=loss, metrics=['accuracy'])
  print(train_data.shape)


  # Train model with Keras
  model.fit(train_data, train_labels,
            epochs=1,validation_data=(test_data,test_labels))#batch_size=FLAGS.batch_size)

  # Compute the privacy budget expended.
  '''if FLAGS.dpsgd:
    eps = compute_epsilon(FLAGS.epochs * 60000 // FLAGS.batch_size)
    print('For delta=1e-5, the current epsilon is: %.2f' % eps)
  else:
    print('Trained with vanilla non-private SGD optimizer')
  '''
  
if __name__ == '__main__':
  tf.app.run()